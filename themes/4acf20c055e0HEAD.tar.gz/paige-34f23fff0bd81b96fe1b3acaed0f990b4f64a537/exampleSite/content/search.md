---
description: "Search the site."
layout: "paige/search"
paige:
  feed:
    hide_page: true
  search:
    hide_page: true
title: "Search"
---
