---
authors: ["will-faught"]
categories: ["layouts", "paige"]
description: "Demonstration of the Paige cloud layout."
layout: "paige/cloud"
tags: ["cloud"]
title: "Cloud Layout"
weight: 20
---

Paige provides a `paige/cloud` layout for taxonomy pages with lots of terms.

<!--more-->

This page has the following parameters:

```yaml
layout: "paige/cloud"
```

Result:
