---
authors: ["will-faught"]
categories: ["content", "paige"]
date: "2023-09-18T21:21:05-07:00"
description: "A complex alert."
paige:
  alert:
    message: "Get more information <a href=\"#\" class=\"alert-link\">here</a>."
    type: "danger"
tags: ["alerts"]
title: "Complex Alert"
weight: 70
---

This page has the following parameters:

```yaml
paige:
  alert:
    message: "Get more information <a href=\"#\" class=\"alert-link\">here</a>."
    type: "danger"
```
