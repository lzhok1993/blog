---
authors: ["will-faught"]
categories: ["content", "paige"]
date: "2023-09-24T21:29:31-07:00"
description: "Only a video."
tags: ["video"]
title: "Video"
weight: 90
---

{{< paige/youtube "dQw4w9WgXcQ" >}}
