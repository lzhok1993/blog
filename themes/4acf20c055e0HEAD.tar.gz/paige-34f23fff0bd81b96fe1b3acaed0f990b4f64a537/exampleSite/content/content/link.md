---
authors: ["will-faught"]
categories: ["content", "paige"]
date: "2023-09-24T21:29:30-07:00"
description: "A front matter link."
link: "https://willfaught.com/paige"
tags: ["link"]
title: "Link"
weight: 80
---

It takes you to the home page.
