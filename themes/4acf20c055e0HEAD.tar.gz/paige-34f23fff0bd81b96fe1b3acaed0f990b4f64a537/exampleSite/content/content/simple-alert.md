---
authors: ["will-faught"]
categories: ["content", "paige"]
date: "2023-09-18T21:33:35-07:00"
description: "A simple alert."
paige:
  alert: "Get more information <a href=\"#\" class=\"alert-link\">here</a>."
tags: ["alerts"]
title: "Simple Alert"
weight: 60
---

This page has the following parameters:

```yaml
paige:
  alert: "Get more information <a href=\"#\" class=\"alert-link\">here</a>."
```
